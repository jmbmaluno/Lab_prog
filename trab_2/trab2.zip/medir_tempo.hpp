#ifndef MEDIR_TEMPO_H
#define MEDIR_TEMPO_H

double medir_tempo(bool (*busca_string) (const char *, const char *, int* ), const char * p, const char * t,  int* o);

#endif