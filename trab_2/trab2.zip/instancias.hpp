#ifndef INSTANCIAS_H
#define INSTANCIAS_H

char letra_aleatoria(const char l);

char * string_aleatoria(int n, const char l);

#endif