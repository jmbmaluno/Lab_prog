Para compilar o programa utilizar o comando:

g++ -Wall -Wextra -std=c++17 -pedantic auxiliares.cpp instancias.cpp algoritmos_busca.cpp medir_tempo.cpp main.cpp -o programa

ou executar o arquivo "compilar.sh"